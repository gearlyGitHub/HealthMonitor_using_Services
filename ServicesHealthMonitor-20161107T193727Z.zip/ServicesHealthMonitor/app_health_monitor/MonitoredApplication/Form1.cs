﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MonitoredApplication;

namespace MonitoredApplication
{
    /// <summary>
    /// The Monitored Application
    /// </summary>
    public partial class MonitoredApplicationForm : Form
    {
        private WatchdogWatcher watchdogWatcher = null;
        public string sAppFileName ;
        public MonitoredApplicationForm()
        {
            InitializeComponent();

            #region WatchdogWatcher initialization

            int watchDogMonitorInterval = 5000;
            sAppFileName = "";
  
            try
            {
                watchDogMonitorInterval = Convert.ToInt32(ConfigurationManager.AppSettings["WatchDogMonitorInterval"]);
                if (watchDogMonitorInterval != 0)
                {
                    watchDogMonitorInterval = 5000;
                }
            }
            catch (Exception ex)
            {
                watchDogMonitorInterval = 5000;
                UpdateListView("ERR", "Monitored Application Notice" + ex.Message);
                UpdateListView("ERR", ex.Message);
            }

            watchdogWatcher = new WatchdogWatcher("WatchDog", "WatchDog.exe", watchDogMonitorInterval);
            // wait for the watchdog monitor to finish loading
            // the watched application state will be updated next
            //System.Threading.Thread.Sleep(2000);
            CreateListView();
            UpdateListView("FYI", "System Started successfully"); //CreateMyListView();
            getWatchDogState();

            #endregion
        }

        /// <summary>
        /// Terminate the monitored application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Terminate_Click(object sender, EventArgs e)
        {
            Process.GetCurrentProcess().Kill();
        }

        /// <summary>
        /// Kill the watchdog application process
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_KillWatchDog_Click(object sender, EventArgs e)
        {
            UpdateListView("FYI", "App kill selected.");
            UpdateListView("FYI", "Recommendation: Select the Start button to restart the monitored app.");
            watchdogWatcher.KillWatchDog();
        }
        private Boolean getWatchDogState()
        {
            string watchdogLockFileName = "watchdoglock";


            try
            {
                if (!File.Exists(watchdogLockFileName))
                {
                    File.Create(watchdogLockFileName);
                    btn_lockWatchDog.Text = "Start Process";
                    UpdateListView("FYI", "App watch started successfully");
                    UpdateListView("FYI", "Monitoring has started");

                }
                else
                {
                    watchdogWatcher.KillWatchDog(); //  kill an exising processes
                    File.Delete(watchdogLockFileName);
                    btn_lockWatchDog.Text = "Stop Process";//"Lock WatchDog";
                    UpdateListView("FYI", "App watch stopped successfully");
                    UpdateListView("FYI", "Monitoring has stopped");

                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Monitored Application Notice: " + ex.Message);
                UpdateListView("ERR", "Monitored Application Notice" + ex.Message);
                UpdateListView("ERR", ex.Message);
            }

            return true;

        }

        /// <summary>
        /// Lock/Unlock the watchdog mechanism by creating/deleting the watchdog lock file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_lockWatchDog_Click(object sender, EventArgs e)
        {
            getWatchDogState();
        }

        private void MonitoredApplicationForm_Load(object sender, EventArgs e)
        {
            // wait for the watchdog monitor to finish loading
            // the watched application state will be updated next
            //System.Threading.Thread.Sleep(2000);
            //getWatchDogState();
            //UpdateListView("System Started successfully"); //CreateMyListView();

        }

        private void CreateListView()
        {
            //  Display grid details
            listView1.View = View.Details;
            //  Add column names
            listView1.Columns.Add("Time", 125, HorizontalAlignment.Left);
            listView1.Columns.Add("Status", 50, HorizontalAlignment.Left);
            listView1.Columns.Add("Information", -2, HorizontalAlignment.Left);

            //  Show grids
            listView1.GridLines = true;
            listView1.Scrollable = true;
        }
        private void UpdateListView(string sColumn2, string sColumn3)
        {

            //  Get current date/time
            DateTime currentTime = DateTime.Now;

            //listView1.Items.Add(new ListViewItem(new[] { currentTime.ToString("dd-MM-yy-ssss"), sColumn2 }));
            listView1.Items.Add(new ListViewItem(new[] { currentTime.ToString("dd-MM-yy H:mm:ss"), sColumn2, sColumn3 }));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDlg.Filter = "Application File(*.exe)|*.exe";
            openFileDlg.ShowDialog();
            fldrPath.Text = openFileDlg.FileName;
            sAppFileName = System.IO.Path.GetFileName(fldrPath.Text);
            WatchDog.ApplicationWatcher applicationWatcher = new WatchDog.ApplicationWatcher("CloudUploader", "WatchDog", 5000);//("CloudUploader", "WatchDog", 5000);
            UpdateListView("FYI", "Identified app to watch: " + sAppFileName); //CreateMyListView();
         }

    }
}     
